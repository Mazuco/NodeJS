// MainTabNavigator.js

import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { TabNavigator, TabBarBottom } from 'react-navigation';

import HomeScreen from '../screens/HomeScreen.js';
import LinksScreen from '../screens/LinksScreen.js';
import SettingsScreen from '../screens/SettingsScreen.js';

export default TabNavigator({
	Home: {
		screen: HomeScreen,
	},
	Links: {
		screen: LinksScreen,
	},
	Settings: {
		screen: SettingsScreen,
	},
}, {
	navigationOptions: ({ navigation }) => ({
		navigationOptions: ({ navigation }) => ({
			tabBarIcon: ({ focused }) => {
				const { routeName } = navigation.state;

				let iconName;
				switch (routeName) {
					case 'Home':
					iconName = `ios-information-circle`;
					break;
					case 'Links':
					iconName = `ios-link`;
					break;
					case 'Settings':
					iconName = `ios-options`;
				}
				return (
					<Ionicons name={iconName}
						size={28} style={{marginBottom: -3}}
						color={focused ? Colors.tabIconSelected :
						Colors.tabIconDefault}
					/>
				);
			},
		}),
	}),
	const Colors = {
	tabIconDefault: '#ccc',
	tabIconSelected: '#2f95dc',
}
	tabBarComponent: TabBarBottom,
	tabBarPosition: 'bottom',
	animationEnabled: false,
	swipeEnabled: false,
});


















