// server/index.js

import express from 'express';
import Expo from 'expo-server-sdk';

const app = express();
const expo = new Expo();

let savedPushTokens = [];
const PORT_NUMBER = 3000;

const handlePushTokens = (message) => {
  // Crie as mensagens que você deseja enviar aos clientes
  let notifications = [];
  for (let pushToken of savedPushTokens) {
    // Cada token push parece ExponentPushToken[xxxxxxxxxxxxxxxxxxxxxx]

    // Veja se todos os seus tokens push parecem válidos para toques push Expo
    if (!Expo.isExpoPushToken(pushToken)) {
      console.error(`Push token ${pushToken} is not a valid Expo push token`);
      continue;
    }

    // Construindo a mensagem (veja https://docs.expo.io/versions/latest/guides/push-notifications.html)
    notifications.push({
      to: pushToken,
      sound: 'default',
      title: 'Message received!',
      body: message,
      data: { message },
    })
  }

  // O serviço de notificação por push da Expo aceita lotes de notificações para
  // que você não precisa enviar 1000 solicitações para enviar 1000 notificações. Nós
  // recomendo que você envie suas notificações para reduzir o número de solicitações
  // e para compactá-los (as notificações com conteúdo semelhante serão exibidas
  // compactado).
  let chunks = expo.chunkPushNotifications(notifications);

  (async () => {
    // Envie os pedaços para o serviço de notificação por push da Expo. tem
    // diferentes estratégias que você poderia usar. Uma simples é enviar um pedaço de cada
    // time, que distribui bem o carregamento ao longo do tempo:
    for (let chunk of chunks) {
      try {
        let receipts = await expo.sendPushNotificationsAsync(chunk);
        console.log(receipts);
      } catch (error) {
        console.error(error);
      }
    }
  })();
}

const saveToken = (token) => {
  if (savedPushTokens.indexOf(token === -1)) {
    savedPushTokens.push(token);
  }
}

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Push Notification Server Running');
});

app.post('/token', (req, res) => {
  saveToken(req.body.token.value);
  console.log(`Received push token, ${req.body.token.value}`);
  res.send(`Received push token, ${req.body.token.value}`);
});

app.post('/message', (req, res) => {
  handlePushTokens(req.body.message);
  console.log(`Received message, ${req.body.message}`);
  res.send(`Received message, ${req.body.message}`);
});

app.listen(PORT_NUMBER, () => {
  console.log(`Server Online on Port ${PORT_NUMBER}`);
});
